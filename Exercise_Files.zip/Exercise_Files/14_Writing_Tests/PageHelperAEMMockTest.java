package com.adobe.training.core;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import com.day.cq.wcm.api.Page;

import io.wcm.testing.mock.aem.junit.AemContext;

public class PageHelperAEMMockTest {
	
	
	/**
	 * Tests the helper methods of the class PageHelper
	 *
	 * An AEM context object (the mock environment) needs to be created to test the methods,
	 * as they require an AEM Page object to be injected.
	 * 
	 * AEM Mocks is a mock implementation that extends the Sling Mocks implementation
	 * http://wcm.io/testing/aem-mock/
	 *
	 * Note that the testable class is under /src/main/java:
	 * com.adobe.training.core.PageHelper.java
	 * 
	 *  To correctly use this testing class:
	 *  -put this file under training.core/src/test/java in the package com.adobe.training.core
	 * 
	 */

	
	@Rule
	public AemContext context = new AemContext();
	
	private Page page;
	
	@Before
	public void setup() throws Exception{
		// Load the test content from a json file
		context.load().json("/trainingproject-content.json", "/content/trainingproject");
		
		// Adapt the resource defined by the path to an AEM Page
		page = context.currentPage("/content/trainingproject/en");
	}
	

	@Test
	public void testGetPageTitle() throws Exception{
		
		assertEquals("New Project", PageHelper.getPageTitle(page));
		
	}
	
	@Test
	public void testGetTitle() throws Exception{
		
		assertEquals("English", PageHelper.getTitle(page));
		
	}

}