package com.adobe.training.core.models;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.apache.sling.servlethelpers.MockSlingHttpServletRequest;

import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.apache.sling.testing.mock.sling.junit.SlingContext;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;


/**
 * Tests the StockModelAdaptFromRequest using the Sling Mock implementation for Sling APIs
 *
 * A Sling context (the mock environment) needs to be created to test the classes.
 * The implementation used in that example is the ResourceResolver mock, 
 * to allow in-memory reading and writing resource data using the Sling Resource API.
 * 
 * It also provides support for Sling Models (Sling Models API 1.1 and Impl 1.1 or higher required)
 *
 * Note that the testable class is under /src/main/java:
 * com.adobe.training.core.models.StockModelAdaptFromRequest.java
 * 
 *  To correctly use this testing class:
 *  -put this file under training.core/src/test/java in the package com.adobe.training.core.models
 * 
 */


public class StockModelSlingMockTest {
	
	private final double EPSILON = 2.0; 


	@Rule
	public final SlingContext context = new SlingContext(ResourceResolverType.RESOURCERESOLVER_MOCK);

	private StockModelAdaptFromRequest stockModel;
	
	
	@Before
	public final void setup() throws Exception{
		// Mock the request object with the class MockSlingHttpServletRequest
		MockSlingHttpServletRequest request = context.request();
		
		// Load the test content from a json file
		context.load().json("/adbe-content.json", "/content/stocks/ADBE");
		
		// Register our model to allow adaptation from the context request
		context.addModelsForClasses(StockModelAdaptFromRequest.class);
		
		// The model accesses the resource data through request suffix
		context.requestPathInfo().setSuffix("/content/stocks/ADBE");
		
		// Adapting the request to our model for testing
		stockModel = request.adaptTo(StockModelAdaptFromRequest.class);
		
	}
	
	
	@Test
	public void testStockModel() {
		
		// Validate that the request has been successfully adapted to the model
		assertNotNull(stockModel);
		// Test if expected and actual values for lastTrade are off by the value of EPSILON  
		assertEquals(220.0, stockModel.getLastTrade(), EPSILON);
	}
	
	
}