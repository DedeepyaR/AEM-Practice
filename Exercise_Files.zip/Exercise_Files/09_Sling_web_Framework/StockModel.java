package com.adobe.training.core.models;

import javax.inject.Named;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.Self;

/**
 * This model represents a stock data structure created from the StockDataImporter:
 * /content/stocks/
 *   + ADBE [sling:OrderedFolder]
 *     + lastTrade [nt:unstructured]
 *       - lastTrade = <value>
 *       - requestDate = <value>
 *       - ..
 */

@Model(adaptables=Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class StockModel{
	
	@Self
	private Resource stock;

	@ChildResource
	private Resource lastTrade;

	@ChildResource
	@Named("lastTrade")
	private ValueMap lastTradeValues;

	// getter functions

	public String getStockSymbol() {

		return stock.getName();
	}

	// uses the resource to read the values
	public Double getLastTrade() {

		return lastTrade.getValueMap().get("lastTrade", Double.class);
	}

	// adapted to ValueMap the code is simpler
	public String getRequestDate() {

		return lastTradeValues.get("requestDate", String.class);
	}

	public double getUpDown() {

		return lastTradeValues.get("upDown", Double.class);
	}
	public double getOpenPrice() {

		return lastTradeValues.get("openPrice", Double.class);
	}
	public double getRangeHigh() {
		return lastTradeValues.get("rangeHigh", Double.class);
	}
	public double getRangeLow() {

		return lastTradeValues.get("rangeLow", Double.class);
	}
	public int getVolume() {

		return lastTradeValues.get("volume", Integer.class);
	}
}
