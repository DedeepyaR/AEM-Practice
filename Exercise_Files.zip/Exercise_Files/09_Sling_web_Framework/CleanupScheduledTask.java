package com.adobe.training.core.schedulers;

import org.apache.sling.api.resource.*;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

@Component(service = Runnable.class, immediate = true)

@Designate(ocd = CleanupScheduledTask.Configuration.class, factory=true)
public class CleanupScheduledTask implements Runnable {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Reference
    private ResourceResolverFactory resolverFactory;

	private String cleanupPath;

	@Activate
	protected void activate(Configuration config) {
		cleanupPath = config.cleanupPath();
	}

	@Modified
	protected void modified(Configuration config) {
		logger.info("Configuration modified");
	}

	@ObjectClassDefinition(name = "Training Cleanup Service")
	public @interface Configuration {
		@AttributeDefinition(
				name = "Cleanup path",
				description = "Path to the node which the scheduler removes at a configured interval",
				type = AttributeType.STRING
		)
		String cleanupPath() default "/mypathtraining";

		@AttributeDefinition(
			name = "Cron like expression",
			description = "Run every so often as defined in the cron job expression.",
			type = AttributeType.STRING
		)
		String scheduler_expression() default "0/30 * * * * ?";
}

	@Override
	public void run() {

		//allows us to get the resourceResolver based on the current session
		Map<String, Object> params = new HashMap<>();
		params.put(ResourceResolverFactory.SUBSERVICE, "training");

		logger.info("!!!Cleanup Task checking: {}", cleanupPath);

		try (ResourceResolver resourceResolver = resolverFactory.getServiceResourceResolver(params)){

			Resource resource = resourceResolver.getResource(cleanupPath);

			if (resource != null) {
				resourceResolver.delete(resource);
				resourceResolver.commit();
				logger.info("!!!node deleted");
			}
		} 	catch (LoginException e) {
			logger.error("!!!resource does not exist", e);
		} catch (PersistenceException e) {
			e.printStackTrace();
		}
	}
}