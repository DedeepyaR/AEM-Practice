package com.adobe.training.core.servlets;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;

import org.osgi.service.component.annotations.Component;

@Component( service = Servlet.class,
name="TrainingTitleServlet",
property = {
"sling.servlet.paths=/bin/trainingproject/titleservlet",
"sling.servlet.extensions=html"
})

//TitleSlingServlet uses resourceTypes and extensions to bind to URLs

/*@Component( service = Servlet.class,
		   	name="TrainingTitleServlet",
			property = {
				"sling.servlet.resourceTypes=/apps/trainingproject/components/content/title",
				"sling.servlet.extensions=html"
			})*/


public class TitleSlingServlet extends SlingSafeMethodsServlet {
	
	private static final long serialVersionUID = 1L;

	@Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
    	response.setHeader("Content-Type", "text/html");
    	response.getWriter().print("<h1>Sling Servlet injected this title</h1>"); 
    	response.getWriter().close();
    }   
}
