package com.adobe.training.core;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component

public class Activator {
	private final Logger logger = LoggerFactory.getLogger(getClass());

    @Activate
    public void startBundle() {
        logger.info("##################Bundle Started##################");
    }

    @Deactivate
    public void stopBundle() {
        logger.info("##################Bundle Stopped##################");
    }

}

