package com.adobe.training.core.servlets;

import java.io.IOException;
import java.util.HashMap;

import javax.jcr.Session;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import com.google.gson.Gson;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.Replicator;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;

/**
 * This Servlet ingests a comma delimited string in the form of:
 * 
 * New Page Path, Page Title, Page Tag, Auto Publish, Template
 *
 * And outputs the AEM page created. 
 * 
 * To test, you must create a content node with a resourceType=trainingproject/tools/pagecreator
 * 
 * /content/pagecreator {sling:resourceType=trainingproject/tools/pagecreator}
 *
 * Example cURL Command:
 * $ curl -u admin:admin -X POST http://localhost:4512/content/pagecreator.json -F importer="/content/trainingproject/en/community,Our Community,/apps/trainingproject/templates/page-home,/etc/tags/we-retail/activity/biking,TRUE"
 *
 */


@Component(service =  Servlet.class,
		   property = {"sling.servlet.resourceTypes=trainingproject/tools/pagecreator",
				       "sling.servlet.methods=POST"
		   })

public class PageCreator extends SlingAllMethodsServlet{
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	private static final long serialVersionUID = 1L;

	@Reference
	private Replicator replicator;
	
	private Resource resource;
	
    @Override
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)throws ServletException,IOException{
		response.setHeader("Content-Type", "application/json");
		HashMap<String, String> resultObject = new HashMap<String, String>();
		Gson jsonResponse = new Gson();

		resource = request.getResource();
		
		String param = request.getParameter("importer");
		String[] newPage = param.split(",");
		try {
			resultObject = createTrainingPage(newPage[0], newPage[1], newPage[2], newPage[3], newPage[4]);
		} catch (Exception e) {
			resultObject.put("Status", "Could not properly parse");
			logger.error("Failure to create page: " + e);
		}

		if(resultObject != null){
			//Write the result to the page
			response.getWriter().print(jsonResponse.toJson(resultObject));
			response.getWriter().close();
		}
	}

	/** Helper method to create the page based on available input
	 * 
	 * @param path JCR location of the page to be created
	 * @param title Page Title
	 * @param template AEM Template this page should be created from. The template must exist in the JCR already.
	 * @param tag Tag must already be created in AEM. The tag will be in the form of a path. Ex /etc/tags/marketing/interest
	 * @param publish boolean to publish the page
	 * @return HashMap
	 */
	private HashMap<String, String> createTrainingPage(String path, String title, String template, String tag, String publish) throws Exception {
		HashMap<String, String> pageInfo = new HashMap<String, String>();
		
		if (path != null) {
			//Parse the path to get the pageNodeName and parentPath
			int lastSlash = path.lastIndexOf("/");
			String pageNodeName = path.substring(lastSlash + 1);
			String parentPath = path.substring(0, lastSlash);
	
			//Set a default template if none is given
			if (template == null || template.isEmpty()) {
				template = "/apps/trainingproject/templates/page-content";
			}
	
			//Create page
			PageManager pageManager = resource.getResourceResolver().adaptTo(PageManager.class);
	
			if (pageManager != null && !parentPath.isEmpty() && !pageNodeName.isEmpty()) {
				Page p = pageManager.create(parentPath,
						pageNodeName,
						template,
						title);
	
				//Add a tag to the page
				if (tag != null && !tag.isEmpty()) {
					//TagManager can be retrieved via adaptTo
					TagManager tm = resource.getResourceResolver().adaptTo(TagManager.class);
					if (tm != null) {
						tm.setTags(p.getContentResource(),
								new Tag[]{tm.resolve(tag)},
								true);
					}
				}
	
	
				//Publish page if requested
				boolean publishPage = Boolean.parseBoolean(publish);
				if (publishPage) {
					//Replicator is exposed as a service
					replicator.replicate(resource.getResourceResolver().adaptTo(Session.class),
							ReplicationActionType.ACTIVATE,
							p.getPath());
				}
				
				pageInfo.put("Status", "Successful");
				pageInfo.put("Location", p.getPath());
				pageInfo.put("Title", p.getTitle());
				pageInfo.put("Template Used", p.getTemplate().getPath());
				pageInfo.put("Tagged with", p.getTags()[0].getTitle());
				pageInfo.put("Was Published", String.valueOf(publishPage));
			}
		}
		
		if(pageInfo.isEmpty()) {
			pageInfo.put("Status", "Could not create a page");
		}
		return pageInfo;
	}

}