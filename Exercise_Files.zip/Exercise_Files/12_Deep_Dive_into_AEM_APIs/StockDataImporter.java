package com.adobe.training.core;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.net.ssl.HttpsURLConnection;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.jcr.JcrUtil;
import com.day.cq.polling.importer.ImportException;
import com.day.cq.polling.importer.Importer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * This class imports from IEX api and creates the data structure example below:
 * 
 * /content/stocks/
 *   + <STOCK_SYMBOL> [sling:OrderedFolder]
 *     + lastTrade [nt:unstructured]
 *         	 - companyName = <value>
 *       	 - sector = <value>
 *           - lastTrade = <value>
 *           - timeOfUpdate = <value>
 *           - dayOfLastUpdate = <value>
 *           - openPrice = <value>
 *           - rangeHigh = <value>
 *           - rangeLow = <value>
 *           - volume = <value>
 *           - upDownPrice = <value>
 *           - week52High = <value>
 *           - week52Low = <value>
 *           - ytdChange = <value>
 *
 */

@Component(service = Importer.class, property = "importer.scheme=stock")

public class StockDataImporter implements Importer {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	//controls the property NAME values to be written to the JCR in lines 170-180:
	private static final String COMPANY = "companyName";
	private static final String SECTOR = "sector";
	private static final String LASTTRADE = "lastTrade";
	private static final String UPDATETIME = "timeOfUpdate";
	private static final String DAYOFUPDATE = "dayOfLastUpdate";
	private static final String OPENPRICE = "openPrice";
	private static final String RANGEHIGH = "rangeHigh";
	private static final String RANGELOW = "rangeLow";
	private static final String VOLUME = "volume";
	private static final String UPDOWN = "upDown";
	private static final String WEEK52HIGH = "week52High";
	private static final String WEEK52LOW = "week52Low";
	private static final String YTDCHANGE = "ytdPercentageChange";
	
	@Reference
	private SlingRepository repo;
	
	@Override
	public void importData(final String scheme, final String dataSource, final Resource resource)
		throws ImportException {
		try {
			// dataSource will be interpreted as the stock symbol
			
			//BW - Updated using the IEX api - https://iextrading.com/developer/docs/#quote
			String iexApiUrl = "https://api.iextrading.com/1.0/stock/" + dataSource + "/quote";
			URL sourceUrl	 = new URL(iexApiUrl);
		    HttpsURLConnection request = (HttpsURLConnection) sourceUrl.openConnection();
		    request.connect();
		    
		    // Convert IEX data return to a JSON object
		    JsonParser parser = new JsonParser();
		    JsonElement root = parser.parse(new InputStreamReader((InputStream) request.getContent())); 
		    //JsonObject will give access to quote data via keys
		    JsonObject allQuoteData = root.getAsJsonObject(); 
			
			logger.info("Last trade for stock symbol {} was {}", dataSource, allQuoteData.get("latestPrice"));

			writeToRepository(dataSource, allQuoteData, resource);
			
		}
		catch (MalformedURLException e) {
			logger.error("MalformedURLException", e);
		}
		catch (IOException e) {
			logger.error("IOException", e);
		}
		catch (RepositoryException e) {
			logger.error("RepositoryException", e);
		}
		
	}
	
	/**
	 * Creates the stock data structure
	 * 
	 *  + <STOCK_SYMBOL> [sling:OrderedFolder]
	 *     + lastTrade [nt:unstructured]
	 *     	 - companyName = <value>
	 *     	 - sector = <value>
	 *       - lastTrade = <value>
	 *       - timeOfUpdate = <value>
	 *       - dayOfLastUpdate = <value>
	 *       - openPrice = <value>
	 *       - rangeHigh = <value>
	 *       - rangeLow = <value>
	 *       - volume = <value>
	 *       - upDownPrice = <value>
	 *       - week52High = <value>
	 *       - week52Low = <value>
	 *       - ytdChange = <value>
	 */
	private void writeToRepository(final String stockSymbol, final JsonObject quoteData, final Resource resource) throws RepositoryException {
		
		logger.info("Stock Symbol: " + stockSymbol);
		logger.info("JsonObject to Write: " + quoteData.toString());

		Session session= repo.loginService("training",null);
		
		//NOTE:  /content/stocks  has to exist in the JCR to successfully adapt resource to Node here. 
		Node parent = resource.adaptTo(Node.class);
		
		if(parent == null) {
			logger.warn("The node " + resource.getPath() + " does not exist. Autocreating.");
			parent = JcrUtil.createPath(resource.getPath(), "sling:OrderedFolder", session);
		}

		if (parent != null) {
			Node stockPageNode = JcrUtil.createPath(parent.getPath() + "/" + stockSymbol, "sling:OrderedFolder", session);
			Node lastTradeNode = JcrUtil.createPath(stockPageNode.getPath() + "/lastTrade", "nt:unstructured", session);
			//use java.time api for Date & Time.  Set time to EST for our application
			ZoneId timeZone = ZoneId.of("America/New_York");
			long latestUpdateTime = quoteData.get("latestUpdate").getAsLong();
			LocalDateTime timePerLatestUpdate = LocalDateTime.ofInstant(Instant.ofEpochMilli(latestUpdateTime),
					timeZone);
			ZonedDateTime timeWithZone = ZonedDateTime.of(timePerLatestUpdate, timeZone);
			DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("hh:mm a zz");
			//will store timeOfUpdate as:  Hour:Minute AM/PM, TimeZone    e.g.   11:34 AM, EDT
			String iexUpdateTimeOfDay = timeWithZone.format(timeFormatter);
			DateTimeFormatter dayFormatter = DateTimeFormatter.ofPattern("E MMMM d, yyyy");
			String dayOfUpdate = timeWithZone.format(dayFormatter);
			lastTradeNode.setProperty(COMPANY, quoteData.get("companyName").getAsString());
			lastTradeNode.setProperty(SECTOR, quoteData.get("sector").getAsString());
			/*
			 * latestPrice & latestUpdate from IEX both STOP at 4pm Eastern Time (New York)
			 *    so - effectively, updates stop at this point and do not resume until the next trading day
			 */
			lastTradeNode.setProperty(LASTTRADE, quoteData.get("latestPrice").getAsDouble());
			lastTradeNode.setProperty(UPDATETIME, iexUpdateTimeOfDay);
			lastTradeNode.setProperty(DAYOFUPDATE, dayOfUpdate);
			lastTradeNode.setProperty(OPENPRICE, quoteData.get("open").getAsDouble());
			lastTradeNode.setProperty(RANGEHIGH, quoteData.get("high").getAsDouble());
			lastTradeNode.setProperty(RANGELOW, quoteData.get("low").getAsDouble());
			lastTradeNode.setProperty(VOLUME, quoteData.get("latestVolume").getAsLong());
			lastTradeNode.setProperty(UPDOWN, quoteData.get("change").getAsDouble());
			lastTradeNode.setProperty(WEEK52HIGH, quoteData.get("week52High").getAsDouble());
			lastTradeNode.setProperty(WEEK52LOW, quoteData.get("week52Low").getAsDouble());
			lastTradeNode.setProperty(YTDCHANGE, quoteData.get("ytdChange").getAsDouble());
		} else {
			logger.error("###### JCR resource: " + resource.getPath() + " needs to be created for Importer to write data");
		}
		session.save();
		session.logout();
	}

	@Override
	public void importData(String scheme, String dataSource, Resource target, String login, String password) throws ImportException {
			importData(scheme, dataSource, target);
		
	}
}