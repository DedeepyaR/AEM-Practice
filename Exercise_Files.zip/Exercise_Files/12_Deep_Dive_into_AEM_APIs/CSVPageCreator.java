package com.adobe.training.core.servlets;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;

import javax.jcr.Session;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import com.google.gson.Gson;

import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.Component;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.Replicator;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;

/**
 * This Servlet ingests a .csv file with the following columns:
 * 
 * New Page Path, Page Title, Page Tag, Auto Publish, Template
 *
 * And outputs AEM pages created. 
 * 
 * To test, you must create a content node with a resourceType=trainingproject/tools/pagecreator
 * 
 * /content/pagecreator {sling:resourceType=trainingproject/tools/pagecreator}
 *
 * Example cURL Command:
 * $ curl -u admin:admin -X POST http://localhost:4512/content/pagecreator.csv.json -F importer=@PageCreator.csv
 *
 */

@Component(	service = Servlet.class,
			property = {
					"sling.servlet.resourceTypes=trainingproject/tools/pagecreator",
					"sling.servlet.selectors=csv",
					"sling.servlet.methods=POST"
					}
			)
public class CSVPageCreator extends SlingAllMethodsServlet {

	private static final long serialVersionUID = 1L;
	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Reference
	private Replicator replicator;

	private Resource resource;

	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Content-Type", "application/json");
		HashMap<String, HashMap<String, String>> resultObject = new HashMap<String, HashMap<String, String>>();
		Gson jsonResponse = new Gson();
		resource = request.getResource();

		String param = request.getParameter("importer");
		byte[] input = param.getBytes();
		InputStream stream = new ByteArrayInputStream(input);
		try {
			resultObject = readCSV(stream);
		} catch (Exception e) {
			logger.error("Failure to Read CSV: " + e);
		}

		if (resultObject != null) {
			//Write the result to the page
			response.getWriter().print(jsonResponse.toJson(resultObject));
			response.getWriter().close();
		}
	}

	/**
	 * Reads the CSV file. The CSV file MUST be in the form of:
	 * <p>
	 * JCR path, Page Title, Page Template, AEM Tag, Publish boolean
	 *
	 * @param stream Stream from the CSV
	 * @return JSON object that contains the results of the page creation process
	 */
	private HashMap<String, HashMap<String, String>> readCSV(InputStream stream) throws IOException, Exception {
		HashMap<String, HashMap<String, String>> out = new HashMap<String, HashMap<String, String>>();
		BufferedReader br = new BufferedReader(new InputStreamReader(stream));

		String line;
		String[] newPage;
		HashMap<String, String> createdPageObject = null;
		//Read each line of the CSV
		while ((line = br.readLine()) != null) {
			newPage = line.split(",");
			String aemTag = null;
			String publishFlag = null;
			String aemTemplatePath = null;

			//If the line has a template, tag, publish flag, set those variables
			if (newPage.length == 5) {
				aemTemplatePath = newPage[2];
				aemTag = newPage[3];
				publishFlag = newPage[4];
			} else if (newPage.length == 4) {
				aemTemplatePath = newPage[2];
				aemTag = newPage[3];
			} else if (newPage.length == 3) {
				publishFlag = newPage[2];
			}

			//As long as there is a path and title, the page can be created
			if ((newPage.length > 1)
					&& !newPage[0].isEmpty()
					&& !newPage[1].isEmpty()) {
				String path = newPage[0];
				String title = newPage[1];
				try {
					createdPageObject = createTrainingPage(path, title, aemTemplatePath, aemTag, publishFlag);
				} catch (Exception e) {
					logger.error(path + " not created successfully: " + e);
				}

				//add the status of the row into the json array
				out.put(title, createdPageObject);
				createdPageObject = null;
			} else {
				createdPageObject = new HashMap<String, String>();
				createdPageObject.put("Status", "Could not properly parse");
				out.put(line,createdPageObject);
				createdPageObject = null;
			}
		}
		br.close();
		return out;
	}

	/**
	 * Helper method to create the page based on available input
	 *
	 * @param path     JCR location of the page to be created
	 * @param title    Page Title
	 * @param template AEM Template this page should be created from. The template must exist in the JCR already.
	 * @param tag      Tag must already be created in AEM. The tag will be in the form of a path. Ex /etc/tags/marketing/interest
	 * @param publish  boolean to publish the page
	 */
	private HashMap<String, String> createTrainingPage(String path, String title, String template, String tag, String publish) throws Exception {
		HashMap<String, String> pageInfo = new HashMap<String, String>();
		
		if (path != null) {
			//Parse the path to get the pageNodeName and parentPath
			int lastSlash = path.lastIndexOf("/");
			String pageNodeName = path.substring(lastSlash + 1);
			String parentPath = path.substring(0, lastSlash);
	
			//Set a default template if none is given
			if (template == null || template.isEmpty()) {
				template = "/apps/trainingproject/templates/page-content";
			}
	
			//Create page
			PageManager pageManager = resource.getResourceResolver().adaptTo(PageManager.class);
	
			if (pageManager != null && !parentPath.isEmpty() && !pageNodeName.isEmpty()) {
				Page p = pageManager.create(parentPath,
						pageNodeName,
						template,
						title);
	
				//Add a tag to the page
				if (tag != null && !tag.isEmpty()) {
					//TagManager can be retrieved via adaptTo
					TagManager tm = resource.getResourceResolver().adaptTo(TagManager.class);
					if (tm != null) {
						tm.setTags(p.getContentResource(),
								new Tag[]{tm.resolve(tag)},
								true);
					}
				}
	
	
				//Publish page if requested
				boolean publishPage = Boolean.parseBoolean(publish);
				if (publishPage) {
					//Replicator is exposed as a service
					replicator.replicate(resource.getResourceResolver().adaptTo(Session.class),
							ReplicationActionType.ACTIVATE,
							p.getPath());
				}
				
				pageInfo.put("Status", "Successful");
				pageInfo.put("Location", p.getPath());
				pageInfo.put("Title", p.getTitle());
				pageInfo.put("Template Used", p.getTemplate().getPath());
				pageInfo.put("Tagged with", p.getTags()[0].getTitle());
				pageInfo.put("Was Published", String.valueOf(publishPage));
			}
		}
		
		if(pageInfo.isEmpty()) {
			pageInfo.put("Status", "Could not create a page");
		}
		return pageInfo;
	}
}