package com.adobe.training.core.servlets;

import com.day.cq.wcm.api.PageManager;
import com.google.gson.Gson;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;

import org.osgi.service.component.annotations.Component;

import javax.jcr.query.Query;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * Example URI: http://localhost:4502/content/trainingproject/en.search.html?q=Lorem&wcmmode=disabled
 *
 */
@Component(service = Servlet.class,
		   property = {"sling.servlet.resourceTypes=trainingproject/components/structure/page",
				       "sling.servlet.selectors=search"})

public class SearchServlet extends SlingSafeMethodsServlet {

	private static final long serialVersionUID = 3169795937693969416L;

	@Override
	public final void doGet(final SlingHttpServletRequest request, final SlingHttpServletResponse response)
			throws ServletException, IOException {
		response.setHeader("Content-Type", "application/json");

		ArrayList resultArray = new ArrayList();
		Gson gson = new Gson();

		try (ResourceResolver rr = request.getResourceResolver()) {

			// Path of the node, which triggers this servlet
			Resource requestingResource = request.getResource();

			// Then adapt the resource tree into a page tree

			PageManager pageManager = rr.adaptTo(PageManager.class);

			// Now we can find the page, that was initiating the search
			String queryingPagePath = pageManager.getContainingPage(requestingResource).getPath();

			String queryTerm = (request.getParameter("q") != null) ? request.getParameter("q") : "";

			String QUERY_STRING = "SELECT * " +
					"FROM [nt:unstructured] AS node " +
					"WHERE ISDESCENDANTNODE([" + queryingPagePath + "]) " +
					"and CONTAINS(node.*, '" + queryTerm + "')";

			Iterator<Resource> resourcesIterator = rr.findResources(QUERY_STRING, Query.JCR_SQL2);

			//Add the search results into the json array
			while (resourcesIterator.hasNext()) {
				Resource foundResource = resourcesIterator.next();
				resultArray.add(foundResource.getPath());
			}

			String json = gson.toJson(resultArray);

			response.getWriter().print(json);
			response.getWriter().close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

